<script>
    import '../app.css';
    import { App } from 'konsta/svelte';
  </script>
  
  <App theme="ios">
    <slot />
  </App>